RCM-CAM PCB Specification
-------------------------------

BOARD STACK:

1. Copper Top
2. Copper Bottom

SILKSCREENS:

1.  Both Layers

PASTE MASKS:

1. Top Layer

BOARD MATERIALS:

RoHS Compliant: YES
Copper: 1oz
Finish: Immersion Gold
Material: FR-406
Thickness: 62 mil
Tg>170
Soldermask: SMOBC BLACK
Silkscreen: White

BOARD TESTING:

Electrical Test: YES
